# EdgeDock
Lavender edge-line dock. Tap it -> app icons -> tap an icon -> the app opens as a small window (up to 6 at once, 2x3 grid).
Window grip: drag = move, drag into the right edge = close, long-press = fullscreen / back to small.
Needs: Overlay permission + Shizuku running. Push to GitHub (main) -> Actions builds the APK (Artifacts).
