package com.ahsan.edgedock

import android.annotation.SuppressLint
import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.view.*
import android.widget.*
import kotlin.concurrent.thread
import kotlin.math.abs

/** Edge dock: tap the lavender line -> app icons -> tap an icon -> app opens as a small window (up to 6 at once, 2x3 grid). */
@SuppressLint("ClickableViewAccessibility")
class DockService : Service() {
    private val MAX = 6
    private lateinit var wm: WindowManager
    private var handle: View? = null
    private var panel: View? = null
    private val ui by lazy { Handler(mainLooper) }
    private val LAV = Color.parseColor("#B8A1E8")
    private val LAV_BG = Color.parseColor("#F5F0FF")

    private class Win(val pkg: String, val slot: Int, val id: Int, var l: Int, var t: Int, val w: Int, val h: Int, val grip: View) {
        var full = false
    }
    private val wins = LinkedHashMap<String, Win>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("dock", "Dock", NotificationManager.IMPORTANCE_MIN))
        startForeground(1, Notification.Builder(this, "dock").setSmallIcon(android.R.drawable.ic_menu_more).setContentTitle("EdgeDock").build())
        showHandle()
    }

    private fun lp(w: Int, h: Int, gravity: Int, x: Int = 0, y: Int = 0) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT
    ).also { it.gravity = gravity; it.x = x; it.y = y }

    private fun toast(m: String) = ui.post { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() }

    // ---- thin lavender line on the right edge ----
    private fun showHandle() {
        val v = View(this).apply {
            background = GradientDrawable().apply { setColor(LAV); cornerRadius = dp(3).toFloat(); setStroke(dp(1), Color.WHITE) }
            setOnClickListener { togglePanel() }
        }
        handle = v; wm.addView(v, lp(dp(6), dp(110), Gravity.END or Gravity.CENTER_VERTICAL))
    }

    // ---- icon panel (icons only, panel stays open so you can open several apps; tap the line again to close) ----
    private fun togglePanel() {
        if (panel != null) { wm.removeView(panel); panel = null; return }
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .filter { it.activityInfo.packageName != packageName }.sortedBy { it.loadLabel(pm).toString().lowercase() }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        apps.forEach { ri ->
            val pkg = ri.activityInfo.packageName
            col.addView(ImageView(this).apply {
                setImageDrawable(ri.loadIcon(pm))
                setOnClickListener { openWindow(pkg) }
            }, LinearLayout.LayoutParams(dp(46), dp(46)).apply { setMargins(0, dp(6), 0, dp(6)) })
        }
        val sv = ScrollView(this).apply {
            addView(col)
            background = GradientDrawable().apply { setColor(LAV_BG); cornerRadius = dp(18).toFloat(); setStroke(dp(2), LAV) }
        }
        panel = sv
        wm.addView(sv, lp(dp(66), (resources.displayMetrics.heightPixels * 0.7).toInt(), Gravity.END or Gravity.CENTER_VERTICAL, dp(10)))
    }

    // ---- 2 columns x 3 rows grid of small windows ----
    private fun slotRect(slot: Int): IntArray {
        val dm = resources.displayMetrics; val m = dp(6); val top = dp(36); val bottom = dp(24)
        val cw = (dm.widthPixels - m * 3) / 2
        val ch = (dm.heightPixels - top - bottom - m * 4) / 3
        return intArrayOf(m + (slot % 2) * (cw + m), top + m + (slot / 2) * (ch + m), cw, ch)
    }

    private fun openWindow(pkg: String) {
        if (!Shell.ready()) { toast("Shizuku permission വേണം"); return }
        if (wins.containsKey(pkg)) { toast("ഇത് ഇപ്പോൾ തന്നെ തുറന്നിട്ടുണ്ട്"); return }
        if (wins.size >= MAX) { toast("പരമാവധി $MAX ആപ്പ്"); return }
        val slot = (0 until MAX).first { s -> wins.values.none { it.slot == s } }
        val (l, t, w, h) = slotRect(slot)
        wins[pkg] = placeholder(pkg, slot)   // reserve the slot immediately
        thread {
            val id = Shell.launchFreeform(pkg, l, t, l + w, t + h)
            ui.post {
                wins.remove(pkg)
                if (id > 0) addWindow(pkg, slot, id, l, t, w, h) else toast("ഈ ആപ്പ് small window ആയി തുറക്കുന്നില്ല")
            }
        }
    }

    private fun placeholder(pkg: String, slot: Int) = Win(pkg, slot, -1, 0, 0, 0, 0, View(this))

    /** Lavender grip on top of each window: drag = move, drag into right edge = close, long-press = fullscreen / back to small. */
    private fun addWindow(pkg: String, slot: Int, id: Int, l: Int, t: Int, w: Int, h: Int) {
        val dm = resources.displayMetrics
        val grip = View(this).apply { background = GradientDrawable().apply { setColor(LAV); cornerRadius = dp(5).toFloat(); setStroke(dp(1), Color.WHITE) } }
        val win = Win(pkg, slot, id, l, t, w, h, grip)
        val p = lp(w / 2, dp(10), Gravity.TOP or Gravity.START, l + w / 4, t + dp(3))
        var downX = 0f; var downY = 0f; var sx = 0; var sy = 0; var moved = false; var longDone = false

        val longPress = Runnable {
            longDone = true
            if (!win.full) {
                win.full = true
                thread { Shell.resize(id, 0, 0, dm.widthPixels, dm.heightPixels) }
                p.x = (dm.widthPixels - p.width) / 2; p.y = dp(30)
            } else {
                win.full = false
                thread { Shell.resize(id, win.l, win.t, win.l + win.w, win.t + win.h) }
                p.x = win.l + win.w / 4; p.y = win.t + dp(3)
            }
            wm.updateViewLayout(grip, p)
        }

        grip.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; sx = p.x; sy = p.y; moved = false; longDone = false; v.postDelayed(longPress, 600) }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - downX) > dp(8) || abs(e.rawY - downY) > dp(8)) { moved = true; v.removeCallbacks(longPress) }
                    if (moved && !longDone && !win.full) { p.x = sx + (e.rawX - downX).toInt(); p.y = sy + (e.rawY - downY).toInt(); wm.updateViewLayout(v, p) }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.removeCallbacks(longPress)
                    if (moved && !longDone && !win.full) {
                        if (e.rawX > dm.widthPixels - dp(40)) {
                            Shell.close(pkg); wm.removeView(v); wins.remove(pkg)
                        } else {
                            win.l = p.x - win.w / 4; win.t = p.y - dp(3)
                            thread { Shell.resize(id, win.l, win.t, win.l + win.w, win.t + win.h) }
                        }
                    }
                }
            }
            true
        }
        wins[pkg] = win; wm.addView(grip, p)
    }

    override fun onDestroy() {
        handle?.let { wm.removeView(it) }; panel?.let { wm.removeView(it) }
        wins.values.forEach { try { wm.removeView(it.grip) } catch (_: Throwable) {} }; wins.clear()
        super.onDestroy()
    }
}
