package com.ahsan.edgedock

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#F5F0FF")); setPadding(48, 48, 48, 48)
        }
        setContentView(root)
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#9B7FD4")); setOnClickListener { f() }
        }.also { root.addView(it, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 16, 0, 16) }) }
        btn("1. Overlay permission") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        btn("2. Shizuku permission") {
            try { Shizuku.requestPermission(1) } catch (e: Throwable) { Toast.makeText(this, "Shizuku app തുറന്ന് start ചെയ്യൂ", Toast.LENGTH_LONG).show() }
        }
        btn("3. Start dock") {
            if (!Settings.canDrawOverlays(this)) Toast.makeText(this, "Overlay permission വേണം", Toast.LENGTH_SHORT).show()
            else try { startForegroundService(Intent(this, DockService::class.java)) }
            catch (e: Throwable) { Toast.makeText(this, "Dock start ആയില്ല: ${e.message}", Toast.LENGTH_LONG).show() }
        }
        btn("Stop dock") { stopService(Intent(this, DockService::class.java)) }

        status = TextView(this).apply { setTextColor(Color.parseColor("#6B5A99")); gravity = Gravity.CENTER; textSize = 14f }
        root.addView(status, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 24, 0, 0) })

        // Android 13+: allow the "Stop" notification to show
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }
    }

    override fun onResume() {
        super.onResume()
        val overlay = Settings.canDrawOverlays(this)
        val shizuku = Shell.ready()
        status.text = "Overlay: ${if (overlay) "✓" else "✗"}    Shizuku: ${if (shizuku) "✓" else "✗"}"
    }
}
